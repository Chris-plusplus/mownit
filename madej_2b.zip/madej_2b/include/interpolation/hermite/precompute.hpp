#pragma once

#include <tuple>

namespace interpolation {

std::tuple<vecf, vecz, size_t> precompute_hermite(const vec2f& ys, const vecf& x);

}