#pragma once

#include "newton/uniform.hpp"
#include "newton/general.hpp"
