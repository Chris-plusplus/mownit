#pragma once

#include "approximation/trigonometric.hpp"
#include "approximation/least_square.hpp"