#pragma once

#include "interpolation/lagrange.hpp"
#include "interpolation/newton.hpp"
#include "interpolation/hermite.hpp"