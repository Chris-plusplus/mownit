#pragma once

namespace matrix {

std::tuple<vecf, matf, vecf> solve(matf A, vecf B);

}