#pragma once

namespace interpolation {

vecf compute_deltas_newton(const vecf& ys);

}