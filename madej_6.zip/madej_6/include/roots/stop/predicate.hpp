#pragma once

namespace roots::stop {

enum class predicate {
	val,
	dx
};

}