#pragma once

namespace error {

vecf abs(fn f, fn W, const vecf& xs);

}