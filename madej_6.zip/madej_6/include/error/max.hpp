#pragma once

namespace error {

flt max(const vecf& abs);
flt max(fn f, fn W, const vecf& xs);

}