#pragma once

#include "gauss_elim_tridiag.hpp"

namespace matrix {

auto thomas = gauss_elim_tridiag;

}