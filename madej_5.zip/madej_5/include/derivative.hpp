#pragma once
//#include <symengine/expression.h>

//fn derivative(SymEngine::RCP<const SymEngine::Basic> f_expr);
//fn nth_derivative(SymEngine::RCP<const SymEngine::Basic> f_expr, size_t n);