#pragma once

#include "error/abs.hpp"
#include "error/max.hpp"
#include "error/sum_squared.hpp"