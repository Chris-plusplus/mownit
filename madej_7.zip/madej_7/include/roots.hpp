#pragma once

#include "roots/newton.hpp"
#include "roots/secant.hpp"
#include "roots/stop/dx.hpp"
#include "roots/stop/val.hpp"
#include "roots/stop/predicate.hpp"
