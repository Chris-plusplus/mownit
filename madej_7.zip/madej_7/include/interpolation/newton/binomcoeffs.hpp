#pragma once

namespace interpolation {

flt binomcoeffs_newton(flt n, size_t k, flt start = 1);

}