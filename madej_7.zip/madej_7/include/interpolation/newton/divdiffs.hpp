#pragma once

namespace interpolation {

vecf divdiffs_newton(const vecf& ys, const vecf& xs);

}