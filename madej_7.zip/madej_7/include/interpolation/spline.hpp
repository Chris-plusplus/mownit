#pragma once

#include "spline/2.hpp"
#include "spline/3.hpp"
