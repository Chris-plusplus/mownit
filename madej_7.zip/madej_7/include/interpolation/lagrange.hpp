#pragma once

#include "lagrange/general.hpp"